import java.util.Arrays;

/*
 * Kelley Kelley
 */

public class SelectionSortDemo {

	public static void main(String[] args) {
		
		int[] a = ArrayUtil.randomIntArray(20, 100);
		System.out.println(Arrays.toString(a));
		
		SelectionSorter sorter = new SelectionSorter(a);
		sorter.sort();
		System.out.println(Arrays.toString(a));
		
	}
	
}

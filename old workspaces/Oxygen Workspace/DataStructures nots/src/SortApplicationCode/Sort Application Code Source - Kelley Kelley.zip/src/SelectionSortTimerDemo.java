import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.util.Scanner;

import javax.swing.JFrame;

/*
 * Kelley Kelley
 */

public class SelectionSortTimerDemo extends JFrame {

	static long[] times = new long[801]; 
	static long[] size = new long[801];
	
	Image dbImage;
	Graphics dbg;
	
	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		System.out.print("Enter array size: (preferably 1)");
		int n = in.nextInt();
		
		for(int i = 0; i <= 800; i++) {
			
			int[] a = ArrayUtil.randomIntArray(n, 100);
			
			SelectionSorter sorter = new SelectionSorter(a);
			
			StopWatch timer = new StopWatch();
			
			timer.start();
			sorter.sort();
			timer.stop();
			
			System.out.println(" Items: " + n + " Elapsed time: " + timer.getElapsedTime() + " milliseconds.");
			
			times[i] = timer.getElapsedTime();
			
			size[i] = n;
			
			n += 100;
			
			
		}
		
		SelectionSortTimerDemo m = new SelectionSortTimerDemo();
		
	}
	
	public void paint(Graphics g) {
		
		dbImage = createImage(getWidth(), getHeight());
		dbg = dbImage.getGraphics();
		draw(dbg);
		g.drawImage(dbImage, 0, 0, this);
		
	}
	
	public SelectionSortTimerDemo() {
		
		this.setTitle("Data In Graph Form");
		this.setVisible(true);
		this.setBackground(Color.DARK_GRAY);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(800, 800);
		
	}
	
	public void draw(Graphics g) {
		
		for(int i = 0; i < times.length; i ++) {
			
			g.setColor(Color.MAGENTA);
			g.fillRect((int)(size[i] - 1)/100, 800-((int)times[i]), 10, 10);
			
		}
		
	}
	
}


/*
 * Kelley Kelley
 */

public class SelectionSorter {

	private int[] a;
	
	public SelectionSorter(int[] anArray) {
		
		a = anArray;
		
	}
	
	public void sort() {
		
		for(int current = 0; current < a.length; current++) {
			
			int pos = current;
			for(int k = current + 1; k < a.length; k++) {
				
				if(a[k] > a[pos])
					pos = k;
				
			}
			
			int temp = a[pos];
			a[pos] = a[current];
			a[current] = temp;
			
		}
		
		/* wanted to make sure they were actually sorted
		for(int i = 0; i < a.length; i++) {
			
			System.out.println(a[i]);
			
		}
		*/
		
	}
	
	private int minimumPosition(int from) {
		
		int minPos = from;
		for(int k = from + 1; k < a.length; k++) {
			
			if(a[k] < a[minPos])
				minPos = k;
			
		}
		
		return minPos;
		
	}
	
	private void swap(int i, int j) {
		
		int temp = a[i];
		a[i] = a[j];
		a[j] = temp;
		
	}
	
}
